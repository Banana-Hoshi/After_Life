using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TetherRobots : MonoBehaviour
{
  bool active;
  Rigidbody rb;
  Transform playerTrans;
  [SerializeField] float speed;
  [SerializeField] float movementLimit;
  [SerializeField] PowerBox box;
  [SerializeField] HydraulicPressButton button;
  [SerializeField] TetherRobotTrigger trigger;
    Animator animator;
  bool unplugged;
  Vector3 originalPos;
  private void Start() {
    originalPos = transform.position;
    rb = GetComponent<Rigidbody>();
    playerTrans = GameObject.Find("Player").GetComponent<Transform>();
        animator = GetComponent<Animator>();
  }
  private void Update() {
    if (box != null) {
      active = box.GetSwitchDown();
    }
    if (button != null) {
      active = button.GetSwitchDown();
    }
    if (active && !unplugged) {
      //ACTIVATE THE ROBOT
      if (trigger.GetChasing()) {
        animator.SetBool("isWireStuck", false);
        animator.SetBool("isRunning1", true);
        rb.velocity = speed * (playerTrans.position - transform.position).normalized;
        if (Vector3.Distance(originalPos, transform.position) > movementLimit) {
          animator.SetBool("isRunning1", false);
          animator.SetBool("isWireStuck", true);
          //BIND THE ROBOT TO YANK ON THE CORD
          transform.position = originalPos + (transform.position - originalPos).normalized * movementLimit;
        }
      }
    } else {
      animator.SetBool("isRunning1", false);
      animator.SetBool("isWireStuck", false);
    }
  }
  public void Unplug() {
    unplugged = true;
  }
}
